'use client';

import React from 'react';
import { ELEMENT_PRESETS, PresetTemplate, PresetForm } from './PresetTemplates';

interface PresetGalleryProps {
  onSelectPreset: (data: Record<string, any>, template: PresetTemplate) => void;
}

export function PresetGallery({ onSelectPreset }: PresetGalleryProps) {
  const [selectedTemplate, setSelectedTemplate] = React.useState<PresetTemplate | null>(null);
  const [searchTerm, setSearchTerm] = React.useState('');
  const [activeCategory, setActiveCategory] = React.useState<string | null>(null);

  // Get unique categories
  const categories = Array.from(new Set(ELEMENT_PRESETS.map(p => p.category)));

  // Filter presets based on search and category
  const filteredPresets = ELEMENT_PRESETS.filter(preset => {
    const matchesSearch = preset.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          preset.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = !activeCategory || preset.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const handlePresetSelect = (data: Record<string, any>, template: PresetTemplate) => {
    onSelectPreset(data, template);
    setSelectedTemplate(null);
  };

  return (
    <div className="w-full bg-slate-900 rounded-lg border border-slate-700 p-6">
      {/* Header */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-white mb-2">Element Presets</h2>
        <p className="text-slate-400">Quick-add construction elements with pre-configured fields</p>
      </div>

      {/* Search Bar */}
      <div className="mb-6">
        <input
          type="text"
          placeholder="Search presets..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:border-amber-500 focus:outline-none transition"
        />
      </div>

      {/* Category Filter */}
      <div className="mb-8 flex flex-wrap gap-2">
        <button
          onClick={() => setActiveCategory(null)}
          className={`px-4 py-2 rounded-full font-semibold transition ${
            activeCategory === null
              ? 'bg-amber-500 text-black'
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          All
        </button>
        {categories.map(category => (
          <button
            key={category}
            onClick={() => setActiveCategory(category)}
            className={`px-4 py-2 rounded-full font-semibold transition ${
              activeCategory === category
                ? 'bg-amber-500 text-black'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Presets Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredPresets.length > 0 ? (
          filteredPresets.map(preset => (
            <button
              key={preset.id}
              onClick={() => setSelectedTemplate(preset)}
              className="p-4 bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-amber-500 rounded-lg transition group text-left"
            >
              <div className="text-4xl mb-3 group-hover:scale-110 transition">{preset.icon}</div>
              <h3 className="text-lg font-bold text-white mb-1">{preset.name}</h3>
              <p className="text-xs text-amber-400 mb-3">{preset.category}</p>
              <p className="text-sm text-slate-400">{preset.description}</p>
              <div className="mt-4 pt-4 border-t border-slate-700">
                <span className="text-xs text-slate-500">{preset.fields.length} fields</span>
              </div>
            </button>
          ))
        ) : (
          <div className="col-span-full py-12 text-center">
            <p className="text-slate-400 text-lg">No presets found matching your search</p>
          </div>
        )}
      </div>

      {/* Form Modal */}
      {selectedTemplate && (
        <PresetForm
          template={selectedTemplate}
          onSubmit={(data) => handlePresetSelect(data, selectedTemplate)}
          onClose={() => setSelectedTemplate(null)}
        />
      )}
    </div>
  );
}
