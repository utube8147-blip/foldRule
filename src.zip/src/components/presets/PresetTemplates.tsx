/* Preset Element Templates for Construction Takeoff */
'use client';

import React, { ReactNode } from 'react';
import { X } from 'lucide-react';

export interface PresetTemplate {
  id: string;
  name: string;
  category: string;
  icon: string;
  fields: PresetField[];
  description: string;
}

export interface PresetField {
  name: string;
  label: string;
  type: 'text' | 'number' | 'select' | 'textarea' | 'checkbox';
  required: boolean;
  placeholder?: string;
  options?: string[];
  defaultValue?: string | number | boolean;
}

interface PresetFormProps {
  template: PresetTemplate;
  onSubmit: (data: Record<string, any>) => void;
  onClose: () => void;
}

export const ELEMENT_PRESETS: PresetTemplate[] = [
  {
    id: 'carcass',
    name: 'Carcass',
    category: 'Structure',
    icon: '🏗️',
    description: 'Building structural carcass and framework',
    fields: [
      { name: 'length', label: 'Length (m)', type: 'number', required: true, placeholder: '0.00' },
      { name: 'width', label: 'Width (m)', type: 'number', required: true, placeholder: '0.00' },
      { name: 'height', label: 'Height (m)', type: 'number', required: true, placeholder: '0.00' },
      { name: 'material', label: 'Material', type: 'select', required: true, options: ['Concrete', 'Steel', 'Mixed'] },
      { name: 'notes', label: 'Notes', type: 'textarea', required: false },
    ]
  },
  {
    id: 'stud-wall',
    name: 'Stud Wall',
    category: 'Walls',
    icon: '🧱',
    description: 'Interior stud wall framing',
    fields: [
      { name: 'length', label: 'Length (m)', type: 'number', required: true, placeholder: '0.00' },
      { name: 'height', label: 'Height (m)', type: 'number', required: true, placeholder: '0.00' },
      { name: 'spacing', label: 'Stud Spacing (mm)', type: 'select', required: true, options: ['400mm', '600mm', '800mm'] },
      { name: 'studSize', label: 'Stud Size', type: 'select', required: true, options: ['50x50mm', '75x50mm', '100x50mm'] },
      { name: 'doubleLayer', label: 'Double Layer', type: 'checkbox', required: false },
    ]
  },
  {
    id: 'floor-slab',
    name: 'Floor Slab',
    category: 'Structure',
    icon: '📐',
    description: 'Concrete floor slabs and platforms',
    fields: [
      { name: 'length', label: 'Length (m)', type: 'number', required: true, placeholder: '0.00' },
      { name: 'width', label: 'Width (m)', type: 'number', required: true, placeholder: '0.00' },
      { name: 'thickness', label: 'Thickness (mm)', type: 'select', required: true, options: ['100mm', '150mm', '200mm', '250mm'] },
      { name: 'reinforcement', label: 'Reinforcement Type', type: 'select', required: true, options: ['Mesh', 'Bars', 'Fibre'] },
      { name: 'finishType', label: 'Finish Type', type: 'select', required: true, options: ['Smooth', 'Rough', 'Polished'] },
    ]
  },
  {
    id: 'roof',
    name: 'Roof',
    category: 'Envelope',
    icon: '🏘️',
    description: 'Roof structures and coverings',
    fields: [
      { name: 'roofArea', label: 'Roof Area (m²)', type: 'number', required: true, placeholder: '0.00' },
      { name: 'roofType', label: 'Roof Type', type: 'select', required: true, options: ['Pitched', 'Flat', 'Curved'] },
      { name: 'roofPitch', label: 'Roof Pitch (degrees)', type: 'number', required: false, placeholder: '0.00' },
      { name: 'material', label: 'Material', type: 'select', required: true, options: ['Tile', 'Slate', 'Metal', 'Asphalt'] },
      { name: 'insulation', label: 'Insulation Thickness (mm)', type: 'select', required: false, options: ['100mm', '150mm', '200mm'] },
    ]
  },
  {
    id: 'door',
    name: 'Door',
    category: 'Openings',
    icon: '🚪',
    description: 'Door frames and installations',
    fields: [
      { name: 'quantity', label: 'Quantity', type: 'number', required: true, placeholder: '1' },
      { name: 'width', label: 'Width (mm)', type: 'select', required: true, options: ['750mm', '800mm', '900mm', '1000mm'] },
      { name: 'height', label: 'Height (mm)', type: 'select', required: true, options: ['2000mm', '2100mm', '2400mm'] },
      { name: 'doorType', label: 'Door Type', type: 'select', required: true, options: ['Swing', 'Sliding', 'Folding', 'Bi-fold'] },
      { name: 'material', label: 'Material', type: 'select', required: true, options: ['Wood', 'Steel', 'Aluminium', 'Glass'] },
      { name: 'frameType', label: 'Frame Type', type: 'select', required: true, options: ['Timber', 'Steel', 'Aluminium'] },
    ]
  },
  {
    id: 'window',
    name: 'Window',
    category: 'Openings',
    icon: '🪟',
    description: 'Window frames and glazing',
    fields: [
      { name: 'quantity', label: 'Quantity', type: 'number', required: true, placeholder: '1' },
      { name: 'width', label: 'Width (mm)', type: 'number', required: true, placeholder: '0.00' },
      { name: 'height', label: 'Height (mm)', type: 'number', required: true, placeholder: '0.00' },
      { name: 'windowType', label: 'Window Type', type: 'select', required: true, options: ['Casement', 'Sash', 'Slider', 'Fixed'] },
      { name: 'glazing', label: 'Glazing Type', type: 'select', required: true, options: ['Single', 'Double', 'Triple'] },
      { name: 'frameType', label: 'Frame Type', type: 'select', required: true, options: ['Timber', 'UPVC', 'Aluminium', 'Steel'] },
    ]
  },
  {
    id: 'ceiling',
    name: 'Ceiling',
    category: 'Interior',
    icon: '🎪',
    description: 'Ceiling systems and finishes',
    fields: [
      { name: 'area', label: 'Area (m²)', type: 'number', required: true, placeholder: '0.00' },
      { name: 'ceilingType', label: 'Ceiling Type', type: 'select', required: true, options: ['Suspended', 'Direct Fix', 'Plasterboard', 'Acoustic'] },
      { name: 'height', label: 'Height from Floor (m)', type: 'number', required: false, placeholder: '0.00' },
      { name: 'gridType', label: 'Grid Type', type: 'select', required: false, options: ['T-bar', 'Clips', 'Adhesive'] },
      { name: 'fireRating', label: 'Fire Rating', type: 'select', required: false, options: ['None', '30min', '60min', '90min'] },
    ]
  },
  {
    id: 'staircase',
    name: 'Staircase',
    category: 'Structure',
    icon: '🪜',
    description: 'Stair construction and railings',
    fields: [
      { name: 'quantity', label: 'Quantity', type: 'number', required: true, placeholder: '1' },
      { name: 'flightRise', label: 'Flight Rise (m)', type: 'number', required: true, placeholder: '0.00' },
      { name: 'stepCount', label: 'Number of Steps', type: 'number', required: true, placeholder: '0' },
      { name: 'stringType', label: 'String Type', type: 'select', required: true, options: ['Open', 'Closed'] },
      { name: 'material', label: 'Material', type: 'select', required: true, options: ['Timber', 'Concrete', 'Steel', 'Composite'] },
      { name: 'railing', label: 'Railing Type', type: 'select', required: false, options: ['Timber', 'Metal', 'Glass', 'None'] },
    ]
  },
  {
    id: 'beam',
    name: 'Beam',
    category: 'Structure',
    icon: '➡️',
    description: 'Structural beams and supports',
    fields: [
      { name: 'quantity', label: 'Quantity', type: 'number', required: true, placeholder: '1' },
      { name: 'length', label: 'Length (m)', type: 'number', required: true, placeholder: '0.00' },
      { name: 'beamType', label: 'Beam Type', type: 'select', required: true, options: ['I-Beam', 'H-Beam', 'Channel', 'Box'] },
      { name: 'material', label: 'Material', type: 'select', required: true, options: ['Steel', 'Concrete', 'Timber'] },
      { name: 'sectionSize', label: 'Section Size', type: 'text', required: true, placeholder: 'e.g., 305x165x40' },
      { name: 'fireProtection', label: 'Fire Protection', type: 'select', required: false, options: ['None', 'Paint', 'Boarding', 'Intumescent'] },
    ]
  },
  {
    id: 'column',
    name: 'Column',
    category: 'Structure',
    icon: '📏',
    description: 'Structural columns and supports',
    fields: [
      { name: 'quantity', label: 'Quantity', type: 'number', required: true, placeholder: '1' },
      { name: 'height', label: 'Height (m)', type: 'number', required: true, placeholder: '0.00' },
      { name: 'columnType', label: 'Column Type', type: 'select', required: true, options: ['Circular', 'Square', 'Rectangular', 'I-Section'] },
      { name: 'material', label: 'Material', type: 'select', required: true, options: ['Steel', 'Concrete', 'Timber'] },
      { name: 'sectionSize', label: 'Section Size', type: 'text', required: true, placeholder: 'e.g., 300x300' },
      { name: 'foundations', label: 'Foundation Type', type: 'select', required: false, options: ['Pile', 'Pad', 'Strip', 'Raft'] },
    ]
  },
  {
    id: 'tiling',
    name: 'Tiling',
    category: 'Finishes',
    icon: '🧩',
    description: 'Wall and floor tiling installation',
    fields: [
      { name: 'area', label: 'Area (m²)', type: 'number', required: true, placeholder: '0.00' },
      { name: 'tilingLocation', label: 'Location', type: 'select', required: true, options: ['Wall', 'Floor', 'Both'] },
      { name: 'tileSize', label: 'Tile Size (mm)', type: 'select', required: true, options: ['200x200', '300x300', '400x400', '600x600'] },
      { name: 'material', label: 'Material', type: 'select', required: true, options: ['Ceramic', 'Porcelain', 'Glass', 'Natural Stone'] },
      { name: 'groutType', label: 'Grout Type', type: 'select', required: true, options: ['Cement', 'Epoxy', 'Urethane'] },
      { name: 'jointWidth', label: 'Joint Width (mm)', type: 'select', required: false, options: ['3mm', '4mm', '5mm', '6mm'] },
    ]
  },
  {
    id: 'plumbing',
    name: 'Plumbing',
    category: 'Services',
    icon: '🔧',
    description: 'Water supply and drainage systems',
    fields: [
      { name: 'pipeLength', label: 'Pipe Length (m)', type: 'number', required: true, placeholder: '0.00' },
      { name: 'pipeType', label: 'Pipe Type', type: 'select', required: true, options: ['Copper', 'PVC', 'HDPE', 'Steel'] },
      { name: 'pipeDiameter', label: 'Diameter (mm)', type: 'select', required: true, options: ['15mm', '20mm', '25mm', '32mm', '50mm'] },
      { name: 'systemType', label: 'System Type', type: 'select', required: true, options: ['Cold Water', 'Hot Water', 'Waste', 'Vent'] },
      { name: 'fittings', label: 'Fittings Type', type: 'select', required: false, options: ['Compression', 'Push-Fit', 'Soldered', 'Threaded'] },
      { name: 'quantity', label: 'Quantity of Fittings', type: 'number', required: false, placeholder: '0' },
    ]
  },
];

export function PresetForm({ template, onSubmit, onClose }: PresetFormProps) {
  const [formData, setFormData] = React.useState<Record<string, any>>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleChange = (fieldName: string, value: any) => {
    setFormData(prev => ({ ...prev, [fieldName]: value }));
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-slate-900 rounded-lg shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto border border-amber-500">
        {/* Header */}
        <div className="sticky top-0 bg-slate-950 border-b border-amber-500 p-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <span className="text-3xl">{template.icon}</span>
            <div>
              <h2 className="text-2xl font-bold text-white">{template.name}</h2>
              <p className="text-amber-400 text-sm">{template.description}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition"
          >
            <X size={24} />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {template.fields.map((field) => (
              <div key={field.name} className={field.type === 'textarea' ? 'md:col-span-2' : ''}>
                <label className="block text-sm font-semibold text-amber-400 mb-2">
                  {field.label}
                  {field.required && <span className="text-red-500 ml-1">*</span>}
                </label>

                {field.type === 'text' && (
                  <input
                    type="text"
                    placeholder={field.placeholder}
                    value={formData[field.name] || ''}
                    onChange={(e) => handleChange(field.name, e.target.value)}
                    required={field.required}
                    className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:border-amber-500 focus:outline-none transition"
                  />
                )}

                {field.type === 'number' && (
                  <input
                    type="number"
                    placeholder={field.placeholder}
                    step="0.01"
                    value={formData[field.name] || ''}
                    onChange={(e) => handleChange(field.name, parseFloat(e.target.value))}
                    required={field.required}
                    className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:border-amber-500 focus:outline-none transition"
                  />
                )}

                {field.type === 'select' && (
                  <select
                    value={formData[field.name] || ''}
                    onChange={(e) => handleChange(field.name, e.target.value)}
                    required={field.required}
                    className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:border-amber-500 focus:outline-none transition"
                  >
                    <option value="">Select {field.label.toLowerCase()}</option>
                    {field.options?.map(opt => (
                      <option key={opt} value={opt}>{opt}</option>
                    ))}
                  </select>
                )}

                {field.type === 'textarea' && (
                  <textarea
                    placeholder={field.placeholder}
                    value={formData[field.name] || ''}
                    onChange={(e) => handleChange(field.name, e.target.value)}
                    required={field.required}
                    rows={3}
                    className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:border-amber-500 focus:outline-none transition resize-none"
                  />
                )}

                {field.type === 'checkbox' && (
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData[field.name] || false}
                      onChange={(e) => handleChange(field.name, e.target.checked)}
                      className="w-5 h-5 rounded border-slate-700 bg-slate-800 accent-amber-500"
                    />
                    <span className="text-white">{field.label}</span>
                  </label>
                )}
              </div>
            ))}
          </div>

          {/* Actions */}
          <div className="flex gap-4 pt-6 border-t border-slate-700">
            <button
              type="submit"
              className="flex-1 bg-amber-500 hover:bg-amber-600 text-black font-bold py-3 px-4 rounded-lg transition transform hover:scale-105"
            >
              Add Measurement
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 bg-slate-800 hover:bg-slate-700 text-white font-bold py-3 px-4 rounded-lg transition"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
