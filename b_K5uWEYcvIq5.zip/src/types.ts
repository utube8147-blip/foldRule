// ─── Tool Types ────────────────────────────────────────────────────────────────
export type ToolType = 'select' | 'point' | 'linear' | 'area' | 'count' | 'scale' | 'text';

// ─── Basic Types ───────────────────────────────────────────────────────────────
export interface Point {
  x: number;
  y: number;
}

// ─── Material Types ────────────────────────────────────────────────────────────
export interface Material {
  id: string;
  code: string;
  name: string;
  category: string;
  unit: string;
  unitRate: number;
  materialCost: number;
  laborCost: number;
  equipmentCost: number;
  supplier?: string;
  sku?: string;
}

// Alias for backward compatibility
export type MaterialSpec = Material;

// ─── Drawing Types ─────────────────────────────────────────────────────────────
export interface Drawing {
  id: string;
  name: string;
  fileUrl: string;
  file?: File;
  scaleFactor: number;
  pageCount: number;
}

// ─── Measurement Types ─────────────────────────────────────────────────────────
export type MeasurementType = 'Length' | 'Area' | 'Count' | 'Point';

export interface TakeoffRow {
  id: string;
  drawingId: string;
  description: string;
  type: MeasurementType;
  quantity: number;
  unit: string;
  unitRate: number;
  notes: string;
  points: Array<{ x: number; y: number }>;
  isOverridden: boolean;
  presetData?: Record<string, any>;
  presetId?: string;
  groupId?: string;
  groupName?: string;
  groupType?: string;
  parentId?: string;
  isGroupHeader?: boolean;
  isExpanded?: boolean;
  category?: string;
  color: string;
  isVisible: boolean;
  materialId?: string;
}

// ─── Project State ─────────────────────────────────────────────────────────────
export interface ProjectState {
  projectName: string;
  projectNumber: string;
  unit: string;
  drawings: Drawing[];
  activeDrawingId: string | null;
  measurements: TakeoffRow[];
  materials: Material[];
}


