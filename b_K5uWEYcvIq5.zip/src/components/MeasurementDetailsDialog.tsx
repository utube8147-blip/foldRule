import React, { useState, useEffect } from 'react';

interface MeasurementDetailsDialogProps {
  isOpen: boolean;
  defaultName: string;
  defaultMaterial: string;
  onConfirm: (name: string, material: string) => void;
  onSkip: () => void;
}

export function MeasurementDetailsDialog({ 
  isOpen, 
  defaultName, 
  defaultMaterial, 
  onConfirm, 
  onSkip 
}: MeasurementDetailsDialogProps) {
  const [name, setName] = useState(defaultName);
  const [material, setMaterial] = useState(defaultMaterial);

  useEffect(() => {
    if (isOpen) {
      setName(defaultName);
      setMaterial(defaultMaterial);
    }
  }, [isOpen, defaultName, defaultMaterial]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm">
      <div 
        className="bg-zinc-900 border border-industrial-border shadow-2xl p-6 w-96"
        onClick={e => e.stopPropagation()}
      >
        <h3 className="text-sm font-mono font-bold text-zinc-200 uppercase tracking-widest mb-4">
          Measurement Details
        </h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-[10px] font-mono font-bold text-zinc-400 uppercase tracking-widest mb-1.5">
              Name
            </label>
            <input
              type="text"
              value={name}
              onChange={e => setName(e.target.value)}
              className="w-full bg-zinc-800 border border-industrial-border px-3 py-2 text-sm font-mono text-zinc-200 focus:outline-none focus:border-amber-400 transition-colors"
              placeholder="e.g., Wall Section A, Column Base, etc."
              autoFocus
            />
          </div>
          
          <div>
            <label className="block text-[10px] font-mono font-bold text-zinc-400 uppercase tracking-widest mb-1.5">
              Material
            </label>
            <input
              type="text"
              value={material}
              onChange={e => setMaterial(e.target.value)}
              className="w-full bg-zinc-800 border border-industrial-border px-3 py-2 text-sm font-mono text-zinc-200 focus:outline-none focus:border-amber-400 transition-colors"
              placeholder="e.g., Concrete, Steel, Wood, etc."
            />
          </div>
        </div>

        <div className="flex gap-3 mt-6">
          <button
            onClick={onSkip}
            className="flex-1 text-[10px] font-mono font-bold uppercase tracking-widest px-3 py-2 border border-zinc-700 text-zinc-400 hover:border-zinc-500 transition-all"
          >
            Skip
          </button>
          <button
            onClick={() => onConfirm(name, material)}
            className="flex-1 text-[10px] font-mono font-bold uppercase tracking-widest px-3 py-2 bg-amber-400 text-black hover:bg-amber-300 transition-all"
          >
            Apply
          </button>
        </div>
      </div>
    </div>
  );
}