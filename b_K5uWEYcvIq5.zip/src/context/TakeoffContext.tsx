'use client';

// ─── TakeoffContext.tsx ───────────────────────────────────────────────────────
//
//  UNIFIED STATE: This context is the single source of truth for:
//    - measurements[]     committed takeoff rows
//    - tempPoints[]       in-progress drawing points (lifted from Viewer)
//    - undo/redo stack    before/after snapshots of both arrays
//
//  UndoEntry = { measurementsBefore, tempPointsBefore, measurementsAfter, tempPointsAfter }
//
//  Every action (place point, commit measurement, delete, update) pushes one
//  entry.  Undo applies the "before" state; redo applies the "after" state.
//  No special cases, no type switching, no sync between two systems.
//
// ─────────────────────────────────────────────────────────────────────────────

import React, {
  createContext, useCallback, useContext, useRef, useState,
} from 'react';
import { TakeoffRow, Drawing, ProjectState } from '@/types';

// ── InProgressPoint (re-exported so Viewer/useMeasurements can import from here)
export type InProgressPoint = { x: number; y: number; snapped: boolean };

// ── Undo entry — full before/after snapshot of both arrays ───────────────────
type UndoEntry = {
  measurementsBefore: TakeoffRow[];
  tempPointsBefore:   InProgressPoint[];
  measurementsAfter:  TakeoffRow[];
  tempPointsAfter:    InProgressPoint[];
};

const MAX_HISTORY = 100;

// ── Context shape ─────────────────────────────────────────────────────────────
interface TakeoffContextValue {
  projectState:        ProjectState;
  setProjectState:     React.Dispatch<React.SetStateAction<ProjectState>>;

  // Tool selection
  activeTool:          string;
  setActiveTool:       (t: string) => void;
  selectedId:          string | null;
  setSelectedId:       (id: string | null) => void;

  // Drawing management
  addDrawing:          (name: string, fileUrl: string, file?: File) => void;
  setActiveDrawingId:  (id: string) => void;
  updateDrawingScale:  (id: string, factor: number) => void;

  // ── Committed measurements ────────────────────────────────────────────────
  addMeasurement:      (m: TakeoffRow) => void;
  updateMeasurement:   (id: string, updates: Partial<TakeoffRow>) => void;
  deleteMeasurement:   (id: string) => void;
  clearAll:            () => void;
  toggleVisibility: (id?: string) => void;

  // ── In-progress drawing points (lifted from Viewer) ───────────────────────
  tempPoints:          InProgressPoint[];

  /** Place one point while drawing — pushes undo entry */
  pushPoint:           (point: InProgressPoint) => void;

  /**
   * Commit a finished measurement and clear tempPoints atomically.
   * Called by useMeasurements after calculating quantity/unit.
   * The pre-finish tempPoints are preserved in the undo entry so Ctrl+Z
   * restores the user back to "still drawing" mode.
   */
  commitMeasurement:   (m: TakeoffRow) => void;

  /** Clear in-progress points without committing (ESC, tool switch, etc.) */
  clearTempPoints:     () => void;

  // ── Undo / Redo ───────────────────────────────────────────────────────────
  undo:                () => void;
  redo:                () => void;
  canUndo:             boolean;
  canRedo:             boolean;
}

// ─── Default project state ────────────────────────────────────────────────────
const defaultProject = (): ProjectState => ({
  projectName:     'New Project',
  projectNumber:   '',
  unit:            'm',  // ← Added default unit
  drawings:        [],
  activeDrawingId: null,
  measurements:    [],
  materials:       [],
});

// ─── Context ──────────────────────────────────────────────────────────────────
const TakeoffContext = createContext<TakeoffContextValue | null>(null);

export function TakeoffProvider({ children }: { children: React.ReactNode }) {
  const [projectState, setProjectState] = useState<ProjectState>(defaultProject);
  const [activeTool,   setActiveTool]   = useState<string>('select');
  const [selectedId,   setSelectedId]   = useState<string | null>(null);

  // ── In-progress drawing points ────────────────────────────────────────────
  const [tempPoints, setTempPoints] = useState<InProgressPoint[]>([]);

  // ── Undo stack ────────────────────────────────────────────────────────────
  const [undoPast,   setUndoPast]   = useState<UndoEntry[]>([]);
  const [undoFuture, setUndoFuture] = useState<UndoEntry[]>([]);

  // Stable refs so callbacks don't go stale
  const measurementsRef = useRef<TakeoffRow[]>([]);
  const tempPointsRef   = useRef<InProgressPoint[]>([]);

  // Keep refs in sync with state
  const syncedSetProjectState: typeof setProjectState = useCallback((updater) => {
    setProjectState(prev => {
      const next = typeof updater === 'function' ? (updater as (p: ProjectState) => ProjectState)(prev) : updater;
      measurementsRef.current = next.measurements;
      return next;
    });
  }, []);

  const syncedSetTempPoints: typeof setTempPoints = useCallback((updater) => {
    setTempPoints(prev => {
      const next = typeof updater === 'function' ? (updater as (p: InProgressPoint[]) => InProgressPoint[])(prev) : updater;
      tempPointsRef.current = next;
      return next;
    });
  }, []);

  // ── Core push-entry helper ────────────────────────────────────────────────
  const pushEntry = useCallback((entry: UndoEntry) => {
    setUndoPast(p => [...p.slice(-MAX_HISTORY), entry]);
    setUndoFuture([]);
  }, []);

  // ── Apply a state snapshot ────────────────────────────────────────────────
  const applySnapshot = useCallback((
    measurements: TakeoffRow[],
    tempPts:      InProgressPoint[],
  ) => {
    syncedSetProjectState(prev => {
      measurementsRef.current = measurements;
      return { ...prev, measurements };
    });
    syncedSetTempPoints(() => {
      tempPointsRef.current = tempPts;
      return tempPts;
    });
  }, [syncedSetProjectState, syncedSetTempPoints]);

  // ── Undo / Redo ───────────────────────────────────────────────────────────
  const undo = useCallback(() => {
    setUndoPast(past => {
      if (past.length === 0) return past;
      const entry = past[past.length - 1];
      const rest  = past.slice(0, -1);
      applySnapshot(entry.measurementsBefore, entry.tempPointsBefore);
      setUndoFuture(f => [entry, ...f]);
      return rest;
    });
  }, [applySnapshot]);

  const redo = useCallback(() => {
    setUndoFuture(future => {
      if (future.length === 0) return future;
      const entry = future[0];
      const rest  = future.slice(1);
      applySnapshot(entry.measurementsAfter, entry.tempPointsAfter);
      setUndoPast(p => [...p, entry]);
      return rest;
    });
  }, [applySnapshot]);

  // ── pushPoint — place one in-progress point ───────────────────────────────
  const pushPoint = useCallback((point: InProgressPoint) => {
    const mBefore  = measurementsRef.current;
    const tBefore  = tempPointsRef.current;
    const tAfter   = [...tBefore, point];

    syncedSetTempPoints(() => {
      tempPointsRef.current = tAfter;
      return tAfter;
    });

    pushEntry({
      measurementsBefore: mBefore,
      tempPointsBefore:   tBefore,
      measurementsAfter:  mBefore,   // measurements unchanged
      tempPointsAfter:    tAfter,
    });
  }, [pushEntry, syncedSetTempPoints]);

  // ── commitMeasurement — finish drawing, add to table, clear tempPoints ────
  const commitMeasurement = useCallback((m: TakeoffRow) => {
    const mBefore = measurementsRef.current;
    const tBefore = tempPointsRef.current;
    const mAfter  = [...mBefore, m];
    const tAfter: InProgressPoint[] = [];

    syncedSetProjectState(prev => {
      measurementsRef.current = mAfter;
      return { ...prev, measurements: mAfter };
    });
    syncedSetTempPoints(() => {
      tempPointsRef.current = tAfter;
      return tAfter;
    });

    pushEntry({
      measurementsBefore: mBefore,
      tempPointsBefore:   tBefore,
      measurementsAfter:  mAfter,
      tempPointsAfter:    tAfter,
    });
  }, [pushEntry, syncedSetProjectState, syncedSetTempPoints]);

  // ── clearTempPoints — ESC / tool switch / cancel ──────────────────────────
  const clearTempPoints = useCallback(() => {
    syncedSetTempPoints(() => {
      tempPointsRef.current = [];
      return [];
    });
  }, [syncedSetTempPoints]);

  // ── addMeasurement — direct add (presets, manual, etc.) ──────────────────
  const addMeasurement = useCallback((m: TakeoffRow) => {
    const mBefore = measurementsRef.current;
    const tBefore = tempPointsRef.current;
    const mAfter  = [...mBefore, m];

    syncedSetProjectState(prev => {
      measurementsRef.current = mAfter;
      return { ...prev, measurements: mAfter };
    });

    pushEntry({
      measurementsBefore: mBefore,
      tempPointsBefore:   tBefore,
      measurementsAfter:  mAfter,
      tempPointsAfter:    tBefore,
    });
  }, [pushEntry, syncedSetProjectState]);

  // ── updateMeasurement ─────────────────────────────────────────────────────
  const updateMeasurement = useCallback((id: string, updates: Partial<TakeoffRow>) => {
    const mBefore = measurementsRef.current;
    const tBefore = tempPointsRef.current;
    const mAfter  = mBefore.map(m => m.id === id ? { ...m, ...updates } : m);

    syncedSetProjectState(prev => {
      measurementsRef.current = mAfter;
      return { ...prev, measurements: mAfter };
    });

    pushEntry({
      measurementsBefore: mBefore,
      tempPointsBefore:   tBefore,
      measurementsAfter:  mAfter,
      tempPointsAfter:    tBefore,
    });
  }, [pushEntry, syncedSetProjectState]);

  // ── deleteMeasurement ─────────────────────────────────────────────────────
  const deleteMeasurement = useCallback((id: string) => {
    const mBefore = measurementsRef.current;
    const tBefore = tempPointsRef.current;
    const mAfter  = mBefore.filter(m => m.id !== id);

    syncedSetProjectState(prev => {
      measurementsRef.current = mAfter;
      return { ...prev, measurements: mAfter };
    });

    pushEntry({
      measurementsBefore: mBefore,
      tempPointsBefore:   tBefore,
      measurementsAfter:  mAfter,
      tempPointsAfter:    tBefore,
    });
  }, [pushEntry, syncedSetProjectState]);

// In TakeoffContext.tsx, update toggleVisibility:

  const toggleVisibility = useCallback((id?: string) => {  // Made id optional
    if (!id) return;
    syncedSetProjectState(prev => ({
      ...prev,
      measurements: prev.measurements.map(m =>
        m.id === id ? { ...m, isVisible: !m.isVisible } : m
      ),
    }));
  }, [syncedSetProjectState]);


  // ── clearAll ──────────────────────────────────────────────────────────────
  const clearAll = useCallback(() => {
    const mBefore = measurementsRef.current;
    const tBefore = tempPointsRef.current;

    syncedSetProjectState(prev => {
      measurementsRef.current = [];
      return { ...prev, measurements: [] };
    });
    syncedSetTempPoints(() => {
      tempPointsRef.current = [];
      return [];
    });

    pushEntry({
      measurementsBefore: mBefore,
      tempPointsBefore:   tBefore,
      measurementsAfter:  [],
      tempPointsAfter:    [],
    });
  }, [pushEntry, syncedSetProjectState, syncedSetTempPoints]);

  // ── Drawing management ────────────────────────────────────────────────────
  const addDrawing = useCallback((name: string, fileUrl: string, file?: File) => {
    const id: string = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    syncedSetProjectState(prev => ({
      ...prev,
      drawings: [...prev.drawings, { id, name, fileUrl, file, scaleFactor: 1, pageCount: 1 }],
      activeDrawingId: id,
    }));
  }, [syncedSetProjectState]);

  const setActiveDrawingId = useCallback((id: string) => {
    syncedSetProjectState(prev => ({ ...prev, activeDrawingId: id }));
    syncedSetTempPoints(() => {
      tempPointsRef.current = [];
      return [];
    });
  }, [syncedSetProjectState, syncedSetTempPoints]);

  const updateDrawingScale = useCallback((id: string, factor: number) => {
    syncedSetProjectState(prev => ({
      ...prev,
      drawings: prev.drawings.map(d => d.id === id ? { ...d, scaleFactor: factor } : d),
    }));
  }, [syncedSetProjectState]);

  // ── Value ─────────────────────────────────────────────────────────────────
  const value: TakeoffContextValue = {
    projectState,
    setProjectState: syncedSetProjectState,
    activeTool,
    setActiveTool,
    selectedId,
    setSelectedId,
    addDrawing,
    setActiveDrawingId,
    updateDrawingScale,
    addMeasurement,
    updateMeasurement,
    deleteMeasurement,
    clearAll,
    toggleVisibility,
    tempPoints,
    pushPoint,
    commitMeasurement,
    clearTempPoints,
    undo,
    redo,
    canUndo: undoPast.length   > 0,
    canRedo: undoFuture.length > 0,
  };

  return (
    <TakeoffContext.Provider value={value}>
      {children}
    </TakeoffContext.Provider>
  );
}

export function useTakeoffContext() {
  const ctx = useContext(TakeoffContext);
  if (!ctx) throw new Error('useTakeoffContext must be used inside TakeoffProvider');
  return ctx;
}